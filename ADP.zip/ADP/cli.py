from ADP import ADP_single_index

model = ADP_single_index(

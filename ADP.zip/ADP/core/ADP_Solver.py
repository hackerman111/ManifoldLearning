from collections.abc import Callable

import numpy as np
from ADP import ADP_Config, ADP_Data, calculate_statistics
from ADP.engine.calculus import (
    calculate_h0_from_adp,
    calculate_rho_k_from_adp,
    generate_proj_from_adp,
)
from ADP.engine.weights import calculate_weight_from_adp
from ADP.solver.LSMR import lsmr
from scipy.sparse.linalg import lsmr


class ADP_Solver:
    def __init__(self, config:  ADP_Config , data : ADP_Data , solver : Callable ):
        # Добавить проверки на None можно в utils
        self.config = config
        self.data = data
        self.solver = solver


    def fit(self):
        X,Y = self.data.X, self.data.Y
        beta_init = self.data.beta_init 
        d = self.data.d
        a = self.config.a
        rng = np.random.default_rng(seed= self.config.seed)

        
        rho_k = 1.0
        h_k = calculate_h0_from_adp(self.config, self.data)

        proj = generate_proj_from_adp(
            self.config,
            self.data,
            rng,
            beta_init,
            rho_k
        )

        weight = calculate_weight_from_adp(
            self.config,
            self.data,
            beta_init,
            h_k,
            rho_k
        )

        stat = calculate_statistics(X,Y,weight,proj)
        beta_k =  lsmr(beta_init,stat.U, stat.Z)

        while h_k / a > self.config.h_min:
            h_k = h_k / a
            rho_k = calculate_rho_k_from_adp(
                self.config,
                self.data,
                beta_k,
                h_k
            )
            proj = generate_proj_from_adp(
                self.config,
                self.data,
                rng,
                beta_k,
                rho_k
            )
            weight = calculate_weight_from_adp(
                self.config,
                self.data,
                beta_k,
                h_k,
                rho_k
            )
            stat = calculate_statistics(X,Y,weight,proj)
            beta_k =  lsmr(beta_k,stat.U, stat.I)

        







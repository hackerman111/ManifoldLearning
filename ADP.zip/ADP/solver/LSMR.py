import numpy as np


def lsmr(beta_init, U, I) -> np.ndarray:
    return beta_init
